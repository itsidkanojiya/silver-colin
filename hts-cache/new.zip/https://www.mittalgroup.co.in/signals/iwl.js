<!DOCTYPE html>
<html lang="en-US" prefix="og: https://ogp.me/ns#">
<head>
			
		<meta charset="UTF-8"/>
		<link rel="profile" href="http://gmpg.org/xfn/11"/>
			
				<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=yes">
			<style>img:is([sizes="auto" i], [sizes^="auto," i]) { contain-intrinsic-size: 3000px 1500px }</style>
	
<!-- Search Engine Optimization by Rank Math - https://s.rankmath.com/home -->
<title>Page Not Found | Mittal Group</title>
<meta name="robots" content="follow, noindex"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="article" />
<meta property="og:title" content="Page Not Found | Mittal Group" />
<meta property="og:site_name" content="Mittal Group" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="Page Not Found | Mittal Group" />
<!-- /Rank Math WordPress SEO plugin -->

<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="Mittal Group &raquo; Feed" href="https://www.mittalgroup.co.in/feed/" />
<link rel="alternate" type="application/rss+xml" title="Mittal Group &raquo; Comments Feed" href="https://www.mittalgroup.co.in/comments/feed/" />
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.mittalgroup.co.in\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.7.1"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://www.mittalgroup.co.in/wp-includes/css/dist/block-library/style.min.css?ver=6.7.1' type='text/css' media='all' />
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='contact-form-7-css' href='https://www.mittalgroup.co.in/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.7.6' type='text/css' media='all' />
<link rel='stylesheet' id='tss-css' href='https://www.mittalgroup.co.in/wp-content/plugins/testimonial-slider-and-showcase/assets/css/wptestimonial.css?ver=2.3.2' type='text/css' media='all' />
<link rel='stylesheet' id='spam-protect-for-contact-form7-css' href='https://www.mittalgroup.co.in/wp-content/plugins/wp-contact-form-7-spam-blocker/frontend/css/spam-protect-for-contact-form7.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='wpos-slick-style-css' href='https://www.mittalgroup.co.in/wp-content/plugins/wp-slick-slider-and-image-carousel/assets/css/slick.css?ver=3.4' type='text/css' media='all' />
<link rel='stylesheet' id='wpsisac-public-style-css' href='https://www.mittalgroup.co.in/wp-content/plugins/wp-slick-slider-and-image-carousel/assets/css/wpsisac-public.css?ver=3.4' type='text/css' media='all' />
<link rel='stylesheet' id='kastell-mkdf-default-style-css' href='https://www.mittalgroup.co.in/wp-content/themes/kastell/style.css?ver=6.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='kastell-mkdf-modules-css' href='https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/css/modules.min.css?ver=6.7.1' type='text/css' media='all' />
<style id='kastell-mkdf-modules-inline-css' type='text/css'>
/* generated in /home/vdamfiniymq4/public_html/wp-content/themes/kastell/framework/modules/search/types/fullscreen/fullscreen.php kastell_mkdf_search_styles function */
.mkdf-fullscreen-search-holder { background-image: url(https://mittalgroup.co.in/wp-content/uploads/2017/12/search-background-img.jpg);background-position: center 0;background-size: cover;background-repeat: no-repeat;}

/* generated in /home/vdamfiniymq4/public_html/wp-content/themes/kastell/framework/admin/options/general/map.php kastell_mkdf_page_general_style function */
.mkdf-wrapper .mkdf-content { background-color: transparent;background-image: url(https://mittalgroup.co.in/wp-content/uploads/2017/12/page-background.jpg);background-size: cover;}

/* generated in /home/vdamfiniymq4/public_html/wp-content/themes/kastell/framework/modules/footer/functions.php kastell_mkdf_footer_background_image function */
.error404 .mkdf-page-footer { background-image: url(https://mittalgroup.co.in/wp-content/uploads/2022/05/footer-bg.jpg);background-size: cover;}

/* generated in /home/vdamfiniymq4/public_html/wp-content/themes/kastell/framework/modules/footer/functions.php kastell_mkdf_footer_background_image function */
.error404 .mkdf-page-footer .mkdf-footer-top-holder, .error404 .mkdf-page-footer .mkdf-footer-bottom-holder { background-color: transparent;}

/* generated in /home/vdamfiniymq4/public_html/wp-content/themes/kastell/framework/modules/widgets/property-filter-widget/functions.php kastell_mkdf_property_styles function */
.mkdf-property-filter-holder { background-image: url(https://mittalgroup.co.in/wp-content/uploads/2018/01/filter-background.jpg);background-position: center 0;background-size: cover;background-repeat: no-repeat;}


</style>
<link rel='stylesheet' id='mkdf-font_awesome-css' href='https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/css/font-awesome/css/font-awesome.min.css?ver=6.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='mkdf-font_elegant-css' href='https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/css/elegant-icons/style.min.css?ver=6.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='mkdf-ion_icons-css' href='https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/css/ion-icons/css/ionicons.min.css?ver=6.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='mkdf-linea_icons-css' href='https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/css/linea-icons/style.css?ver=6.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='mkdf-linear_icons-css' href='https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/css/linear-icons/style.css?ver=6.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='mkdf-simple_line_icons-css' href='https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/css/simple-line-icons/simple-line-icons.css?ver=6.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='mkdf-dripicons-css' href='https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/css/dripicons/dripicons.css?ver=6.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='mediaelement-css' href='https://www.mittalgroup.co.in/wp-includes/js/mediaelement/mediaelementplayer-legacy.min.css?ver=4.2.17' type='text/css' media='all' />
<link rel='stylesheet' id='wp-mediaelement-css' href='https://www.mittalgroup.co.in/wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=6.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='kastell-mkdf-style-dynamic-css' href='https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/css/style_dynamic.css?ver=1684733584' type='text/css' media='all' />
<link rel='stylesheet' id='kastell-mkdf-modules-responsive-css' href='https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/css/modules-responsive.min.css?ver=6.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='kastell-mkdf-style-dynamic-responsive-css' href='https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/css/style_dynamic_responsive.css?ver=1684733584' type='text/css' media='all' />
<link rel='stylesheet' id='kastell-mkdf-google-fonts-css' href='https://fonts.googleapis.com/css?family=Open+Sans%3A300%2C400%2C500%2C600%2C700%2C800%2C900%7COld+Standard+TT%3A300%2C400%2C500%2C600%2C700%2C800%2C900%7CMuli%3A300%2C400%2C500%2C600%2C700%2C800%2C900&#038;subset=latin-ext&#038;ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='pscrollbar-css' href='https://www.mittalgroup.co.in/wp-content/plugins/quadmenu/assets/frontend/pscrollbar/perfect-scrollbar.min.css?ver=2.3.7' type='text/css' media='all' />
<link rel='stylesheet' id='owlcarousel-css' href='https://www.mittalgroup.co.in/wp-content/plugins/quadmenu/assets/frontend/owlcarousel/owl.carousel.min.css?ver=2.3.7' type='text/css' media='all' />
<link rel='stylesheet' id='quadmenu-normalize-css' href='https://www.mittalgroup.co.in/wp-content/plugins/quadmenu/assets/frontend/css/quadmenu-normalize.min.css?ver=2.3.7' type='text/css' media='all' />
<link rel='stylesheet' id='quadmenu-widgets-css' href='https://www.mittalgroup.co.in/wp-content/uploads/kastell-child/quadmenu-widgets.css?ver=1672056072' type='text/css' media='all' />
<link rel='stylesheet' id='quadmenu-css' href='https://www.mittalgroup.co.in/wp-content/plugins/quadmenu/assets/frontend/css/quadmenu.min.css?ver=2.3.7' type='text/css' media='all' />
<link rel='stylesheet' id='quadmenu-locations-css' href='https://www.mittalgroup.co.in/wp-content/uploads/kastell-child/quadmenu-locations.css?ver=1672056072' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css' href='https://www.mittalgroup.co.in/wp-includes/css/dashicons.min.css?ver=6.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='redux-google-fonts-quadmenu_kastell-child-css' href='https://fonts.googleapis.com/css?family=Muli%3A600%2C700&#038;ver=1672056070' type='text/css' media='all' />
<link rel='stylesheet' id='kastell-mkdf-child-style-css' href='https://www.mittalgroup.co.in/wp-content/themes/kastell-child/style.css?ver=6.7.1' type='text/css' media='all' />
<!--n2css--><script type="text/javascript" src="https://www.mittalgroup.co.in/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/plugins/wp-contact-form-7-spam-blocker/frontend/js/spam-protect-for-contact-form7.js?ver=1.0.0" id="spam-protect-for-contact-form7-js"></script>
<link rel="https://api.w.org/" href="https://www.mittalgroup.co.in/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.mittalgroup.co.in/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.7.1" />


<script>
document.addEventListener( 'wpcf7mailsent', function( event ) {
  location = 'https://www.mittalgroup.co.in/thank-you';
}, false );
</script>

<meta name="facebook-domain-verification" content="019o3nbu90pt5lagcbi8l5gmtzsrx8" />


        
<!-- Global site tag (gtag.js) - Google Ads: 10995262179 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-10995262179"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-10995262179');
</script>    

<script>
  gtag('config', 'AW-10995262179/kJulCIr_leIDEOPF-foo', {
    'phone_conversion_number': '01642240163'
  });
</script>



<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '656566555891414');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=656566555891414&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->

<script>
function squareGaj(){
	var sqGaj = document.getElementById("sqGaj").value;
	if(!isNaN(sqGaj)){
	var unit = 8.91359;
	document.getElementById("sqfeet-gaj").value = (document.getElementById("sqGaj").value * unit).toFixed(4);
	}
}
</script>
    
    

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<link rel="icon" href="https://www.mittalgroup.co.in/wp-content/uploads/2022/08/favicon.png" sizes="32x32" />
<link rel="icon" href="https://www.mittalgroup.co.in/wp-content/uploads/2022/08/favicon.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://www.mittalgroup.co.in/wp-content/uploads/2022/08/favicon.png" />
<meta name="msapplication-TileImage" content="https://www.mittalgroup.co.in/wp-content/uploads/2022/08/favicon.png" />
		<style type="text/css" id="wp-custom-css">
			.single-post h1 {  font-size: 30px; }
.single-post h2 {  font-size: 30px; }
.single-post h3 { font-size: 27px; }

.single-property-item h1{ font-size: 55px; }


.pum-responsive .mkdf-grid-col-12 {
    margin-bottom: 10px;
}

.phtxt{ font-size:24px; font-weight:600; }

.highno{
	font-size:35px;
	font-weight:800;
}

p.mailpoet_validate_success {
    color: white;
}
img.capnum {
    background: #fff;
    padding: 8px 10px;
    border: solid 1px #e1e1e1;
    min-width: 120px;
    box-sizing: border-box;
}

.wpcf7-captchar {
    color: #7b7b7b !important;
}
.page-id-3051 input.wpcf7-form-control.wpcf7-captchar {
    margin-left: 37px;
    width: 89%;
}

#respond input[type=text], #respond textarea, 
.mkdf-style-form textarea, .post-password-form input[type=password], 
.wpcf7-form-control.wpcf7-date, .wpcf7-form-control.wpcf7-number, 
.wpcf7-form-control.wpcf7-quiz, .wpcf7-form-control.wpcf7-select, .wpcf7-form-control.wpcf7-text, 
.wpcf7-form-control.wpcf7-textarea, input[type=text], input[type=email], input[type=password] {
    margin: 0 0 12px;
}
.group-title {
    padding-bottom: 20px;
}

.property-form-colum textarea.wpcf7-textarea {
    height: 110px;
}


img.cappro {
    background: #fff;
    padding: 11px 10px;
    border: solid 1px #e1e1e1;
    min-width: 100px;
    box-sizing: border-box;
}

ul#ramid {
    font-size: 20px;
}
}

h1.entry-title.mkdf-post-title {
    font-size: 36px !important;
}

.single-post .has-post-thumbnail img.attachment-full.size-full.wp-post-image {
    display: none;
}  
.has-post-thumbnail .mkdf-post-date-day {
    display: none;
}
.has-post-thumbnail .mkdf-post-date-month {
    display: none;
}
.mkdf-post-date-inner {
	display: none !important;
}
.mkdf-post-date-inner {
    display: none !important;
}
.mkdf-post-info-date.entry-date.published.updated {
    display: none !important;
}
		</style>
		<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style id="wpforms-css-vars-root">
				:root {
					--wpforms-field-border-radius: 3px;
--wpforms-field-background-color: #ffffff;
--wpforms-field-border-color: rgba( 0, 0, 0, 0.25 );
--wpforms-field-text-color: rgba( 0, 0, 0, 0.7 );
--wpforms-label-color: rgba( 0, 0, 0, 0.85 );
--wpforms-label-sublabel-color: rgba( 0, 0, 0, 0.55 );
--wpforms-label-error-color: #d63637;
--wpforms-button-border-radius: 3px;
--wpforms-button-background-color: #066aab;
--wpforms-button-text-color: #ffffff;
--wpforms-field-size-input-height: 43px;
--wpforms-field-size-input-spacing: 15px;
--wpforms-field-size-font-size: 16px;
--wpforms-field-size-line-height: 19px;
--wpforms-field-size-padding-h: 14px;
--wpforms-field-size-checkbox-size: 16px;
--wpforms-field-size-sublabel-spacing: 5px;
--wpforms-field-size-icon-size: 1;
--wpforms-label-size-font-size: 16px;
--wpforms-label-size-line-height: 19px;
--wpforms-label-size-sublabel-font-size: 14px;
--wpforms-label-size-sublabel-line-height: 17px;
--wpforms-button-size-font-size: 17px;
--wpforms-button-size-height: 41px;
--wpforms-button-size-padding-h: 15px;
--wpforms-button-size-margin-top: 10px;

				}
			</style></head>
<body class="error404 mkd-core-1.3.1 kastell child-child-ver-1.0.1 kastell-ver-1.6 mkdf-smooth-scroll mkdf-smooth-page-transitions mkdf-smooth-page-transitions-fadeout mkdf-grid-1300 mkdf-sticky-header-on-scroll-up mkdf-dropdown-animate-height mkdf-header-standard mkdf-menu-area-in-grid-shadow-disable mkdf-menu-area-border-disable mkdf-menu-area-in-grid-border-disable mkdf-logo-area-border-disable mkdf-logo-area-in-grid-border-disable mkdf-header-vertical-shadow-disable mkdf-header-vertical-border-disable mkdf-default-mobile-header mkdf-sticky-up-mobile-header mkdf-fullscreen-search mkdf-search-fade wpb-js-composer js-comp-ver-6.11.0 vc_responsive" itemscope itemtype="http://schema.org/WebPage">
		
	<div class="mkdf-wrapper mkdf-404-page">
		<div class="mkdf-wrapper-inner">
            <div class="mkdf-property-filter-holder">
    <div class="mkdf-property-filter-title-holder">
        <div class="mkdf-property-filter-title">Find Property:</div>
    </div>
    <a class="mkdf-property-filter-close" href="javascript:void(0)">
        <i class="mkdf-icon-ion-icon ion-ios-close-empty " ></i>    </a>
    <div class="mkdf-property-filter-holder-inner">
        
<div class="mkdf-ips mkdf-ips-light">
    <div class="mkdf-ips-holder">
                    <div class="mkdf-ips-content-holder">
                <div class="mkdf-ips-content-table">
                    <div class="mkdf-ips-content-table-cell">
                                                <div class="mkdf-ips-item-content item-1">
                                <a class="mkdf-ips-item-link" itemprop="url" target="_self" href="https://www.mittalgroup.co.in/develop-a-sense-of-calmness-with-mittal-group/" style="text-align: left">
                                    Develop A Sense Of Calmness With Mittal Group!                                </a>
                            </div>
                                                    <div class="mkdf-ips-item-content item-2">
                                <a class="mkdf-ips-item-link" itemprop="url" target="_self" href="https://www.mittalgroup.co.in/ganpati-enclave-bathinda/" style="text-align: left">
                                    Ganpati Enclave                                </a>
                            </div>
                                                    <div class="mkdf-ips-item-content item-3">
                                <a class="mkdf-ips-item-link" itemprop="url" target="_self" href="https://www.mittalgroup.co.in/sushant-city-2/" style="text-align: left">
                                    Sushant City &#8211; 2                                </a>
                            </div>
                                                    <div class="mkdf-ips-item-content item-4">
                                <a class="mkdf-ips-item-link" itemprop="url" target="_self" href="https://www.mittalgroup.co.in/sushant-city-1/" style="text-align: left">
                                    Sushant City &#8211; 1                                </a>
                            </div>
                                                    <div class="mkdf-ips-item-content item-5">
                                <a class="mkdf-ips-item-link" itemprop="url" target="_self" href="https://www.mittalgroup.co.in/sheesh-mahal-heights/" style="text-align: left">
                                    Sheesh Mahal Heights                                </a>
                            </div>
                                                    <div class="mkdf-ips-item-content item-6">
                                <a class="mkdf-ips-item-link" itemprop="url" target="_self" href="https://www.mittalgroup.co.in/dd-mittal-towers/" style="text-align: left">
                                    DD Mittal Towers                                </a>
                            </div>
                                                    <div class="mkdf-ips-item-content item-7">
                                <a class="mkdf-ips-item-link" itemprop="url" target="_self" href="https://www.mittalgroup.co.in/sheesh-mahal-bathinda/" style="text-align: left">
                                    Sheesh Mahal                                </a>
                            </div>
                                                    <div class="mkdf-ips-item-content item-8">
                                <a class="mkdf-ips-item-link" itemprop="url" target="_self" href="https://www.mittalgroup.co.in/mittal-city-mall/" style="text-align: left">
                                    Mittal City Mall                                </a>
                            </div>
                                                    <div class="mkdf-ips-item-content item-9">
                                <a class="mkdf-ips-item-link" itemprop="url" target="_self" href="https://www.mittalgroup.co.in/sheesh-mahal-plaza/" style="text-align: left">
                                    Sheesh Mahal Plaza                                </a>
                            </div>
                                                    <div class="mkdf-ips-item-content item-10">
                                <a class="mkdf-ips-item-link" itemprop="url" target="_self" href="https://www.mittalgroup.co.in/sheesh-mahal-skyline/" style="text-align: left">
                                    Sheesh Mahal Skyline                                </a>
                            </div>
                                                    <div class="mkdf-ips-item-content item-11">
                                <a class="mkdf-ips-item-link" itemprop="url" target="_self" href="https://www.mittalgroup.co.in/sushant-city-2-independent-floors/" style="text-align: left">
                                    Sushant City–2 Independent Floors                                </a>
                            </div>
                                                    <div class="mkdf-ips-item-content item-12">
                                <a class="mkdf-ips-item-link" itemprop="url" target="_self" href="https://www.mittalgroup.co.in/ganpati-temple/" style="text-align: left">
                                    Ganpati Temple                                </a>
                            </div>
                                                    <div class="mkdf-ips-item-content item-13">
                                <a class="mkdf-ips-item-link" itemprop="url" target="_self" href="https://www.mittalgroup.co.in/tulips-club-stadium/" style="text-align: left">
                                    Tulips Club &#038; Stadium                                </a>
                            </div>
                                            </div>
                </div>
            </div>
            </div>
</div>    </div>
</div><div class="mkdf-fullscreen-search-holder">
	<a class="mkdf-fullscreen-search-close" href="javascript:void(0)">
		<span aria-hidden="true" class="mkdf-icon-font-elegant icon_close " ></span>	</a>
	<div class="mkdf-fullscreen-search-table">
		<div class="mkdf-fullscreen-search-cell">
			<div class="mkdf-fullscreen-search-inner">
				<form action="https://www.mittalgroup.co.in/" class="mkdf-fullscreen-search-form" method="get">
					<div class="mkdf-form-holder">
						<div class="mkdf-form-holder-inner">
							<div class="mkdf-field-holder">
								<input type="text" placeholder="Search..." name="s" class="mkdf-search-field" autocomplete="off"/>
							</div>
							<button type="submit" class="mkdf-search-submit"><span aria-hidden="true" class="mkdf-icon-font-elegant icon_search " ></span></button>
							<div class="mkdf-line"></div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<header class="mkdf-page-header">
		
				
	<div class="mkdf-menu-area mkdf-menu-left">
				
						
			<div class="mkdf-vertical-align-containers">
				<div class="mkdf-position-left">
					<div class="mkdf-position-left-inner">
						

<div class="mkdf-logo-wrapper">
    <a itemprop="url" href="https://www.mittalgroup.co.in/" style="height: 47px;">
        <img itemprop="image" class="mkdf-normal-logo" src="https://mittalgroup.co.in/wp-content/uploads/2022/05/logo.png" width="147" height="95"  alt="logo"/>
        <img itemprop="image" class="mkdf-dark-logo" src="https://mittalgroup.co.in/wp-content/uploads/2022/05/logo.png" width="147" height="95"  alt="dark logo"/>        <img itemprop="image" class="mkdf-light-logo" src="https://mittalgroup.co.in/wp-content/uploads/2022/05/logo-light.png" width="147" height="95"  alt="light logo"/>    </a>
</div>

													
<nav class="mkdf-main-menu mkdf-drop-down mkdf-default-nav">
    <nav id="quadmenu" class="quadmenu-default_theme quadmenu-v2.3.7 quadmenu-align-right quadmenu-divider-hide quadmenu-carets-show quadmenu-background-color quadmenu-mobile-shadow-show quadmenu-dropdown-shadow-show quadmenu-hover-ripple mega-class quadmenu-is-embed" data-template="embed" data-theme="default_theme" data-unwrap="0" data-breakpoint="768">
  <div class="quadmenu-container">
    <div id="quadmenu_0" class="quadmenu-navbar-collapse collapsed in">
      <ul class="quadmenu-navbar-nav"><li id="menu-item-3389" class="quadmenu-item-3389 quadmenu-item quadmenu-item-object-page quadmenu-item-home quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-0 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">        <a  href="https://www.mittalgroup.co.in/">
      <span class="quadmenu-item-content">
        <span>                                      <span class="quadmenu-text  hover t_1000">Home</span>
                                      </span>      </span>
    </a>
        </li><li id="menu-item-5099" class="quadmenu-item-5099 quadmenu-item quadmenu-item-object-mega quadmenu-item-has-children quadmenu-item-type-mega quadmenu-item-level-0 quadmenu-dropdown quadmenu-has-caret quadmenu-has-title quadmenu-has-link quadmenu-dropdown-right">        <a  title="Properties in Bathinda" href="https://www.mittalgroup.co.in/real-estate-projects/" class="quadmenu-dropdown-toggle hoverintent">
      <span class="quadmenu-item-content">
        <span>                      <span class="quadmenu-caret"></span>
                            <span class="quadmenu-text  hover t_1000">Projects</span>
                                      </span>      </span>
    </a>
            <div id="dropdown-5099" class="quadmenu_btt t_300 quadmenu-dropdown-menu quadmenu-dropdown-stretch-boxed">
            <ul class="quadmenu-row">
        <li id="menu-item-5100" class="quadmenu-item-5100 quadmenu-item quadmenu-item-object-column quadmenu-item-has-children quadmenu-item-type-column col-xs-12 col-sm-4">    <div id="dropdown-5100" class="">
            <ul>
        <li id="menu-item-5103" class="quadmenu-item-5103 quadmenu-item quadmenu-item-object-widget quadmenu-item-type-widget">        <div class="quadmenu-item-widget widget widget_nav_menu">
          <span class="quadmenu-title">RESIDENTIAL</span><div class="menu-residential-container"><ul id="menu-residential" class="menu"><li id="menu-item-4877" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4877"><a href="https://www.mittalgroup.co.in/ganpati-enclave-bathinda/">Ganpati Enclave</a></li>
<li id="menu-item-4878" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4878"><a href="https://www.mittalgroup.co.in/sheesh-mahal-bathinda/">Sheesh Mahal</a></li>
<li id="menu-item-4879" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4879"><a href="https://www.mittalgroup.co.in/sushant-city-1/">Sushant City – 1</a></li>
<li id="menu-item-4880" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4880"><a href="https://www.mittalgroup.co.in/sushant-city-2/">Sushant City – 2</a></li>
<li id="menu-item-4881" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4881"><a href="https://www.mittalgroup.co.in/dd-mittal-towers/">DD Mittal Towers</a></li>
<li id="menu-item-4882" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4882"><a href="https://www.mittalgroup.co.in/sheesh-mahal-heights/">Sheesh Mahal Heights</a></li>
<li id="menu-item-4883" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-has-children menu-item-4883"><a href="https://www.mittalgroup.co.in/sheesh-mahal-skyline/">Sheesh Mahal Skyline</a>
<ul class="sub-menu">
	<li id="menu-item-5098" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5098"><a href="https://www.mittalgroup.co.in/environmental-clearance/">Environmental Clearance</a></li>
</ul>
</li>
<li id="menu-item-4884" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4884"><a href="https://www.mittalgroup.co.in/sushant-city-2-independent-floors/">Sushant City–2 Independent Floors</a></li>
</ul></div>        </div>
        </li>      </ul>
    </div>
    </li><li id="menu-item-5101" class="quadmenu-item-5101 quadmenu-item quadmenu-item-object-column quadmenu-item-has-children quadmenu-item-type-column col-xs-12 col-sm-4">    <div id="dropdown-5101" class="">
            <ul>
        <li id="menu-item-5104" class="quadmenu-item-5104 quadmenu-item quadmenu-item-object-widget quadmenu-item-type-widget">        <div class="quadmenu-item-widget widget widget_nav_menu">
          <span class="quadmenu-title">COMMERCIAL</span><div class="menu-commercial-container"><ul id="menu-commercial" class="menu"><li id="menu-item-4885" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4885"><a href="https://www.mittalgroup.co.in/mittal-city-mall/">Mittal City Mall</a></li>
<li id="menu-item-4886" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4886"><a href="https://www.mittalgroup.co.in/sheesh-mahal-plaza/">Sheesh Mahal Plaza</a></li>
</ul></div>        </div>
        </li>      </ul>
    </div>
    </li><li id="menu-item-5102" class="quadmenu-item-5102 quadmenu-item quadmenu-item-object-column quadmenu-item-has-children quadmenu-item-type-column col-xs-12 col-sm-4">    <div id="dropdown-5102" class="">
            <ul>
        <li id="menu-item-5105" class="quadmenu-item-5105 quadmenu-item quadmenu-item-object-widget quadmenu-item-type-widget">        <div class="quadmenu-item-widget widget widget_nav_menu">
          <span class="quadmenu-title">OUR SPECIFICS</span><div class="menu-our-specifics-container"><ul id="menu-our-specifics" class="menu"><li id="menu-item-5022" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-5022"><a href="https://www.mittalgroup.co.in/ganpati-temple/">Ganpati Temple</a></li>
<li id="menu-item-5021" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-5021"><a href="https://www.mittalgroup.co.in/tulips-club-stadium/">Tulips Club &#038; Stadium</a></li>
</ul></div>        </div>
        </li>      </ul>
    </div>
    </li>      </ul>
    </div>
    </li><li id="menu-item-3429" class="quadmenu-item-3429 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-0 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">        <a  href="https://www.mittalgroup.co.in/mittal-group/">
      <span class="quadmenu-item-content">
        <span>                                      <span class="quadmenu-text  hover t_1000">About</span>
                                      </span>      </span>
    </a>
        </li><li id="menu-item-3974" class="quadmenu-item-3974 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-0 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">        <a  href="https://www.mittalgroup.co.in/careers/">
      <span class="quadmenu-item-content">
        <span>                                      <span class="quadmenu-text  hover t_1000">Careers</span>
                                      </span>      </span>
    </a>
        </li><li id="menu-item-3416" class="quadmenu-item-3416 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-0 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">        <a  href="https://www.mittalgroup.co.in/blog/">
      <span class="quadmenu-item-content">
        <span>                                      <span class="quadmenu-text  hover t_1000">Blogs</span>
                                      </span>      </span>
    </a>
        </li><li id="menu-item-3417" class="quadmenu-item-3417 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-0 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">        <a  href="https://www.mittalgroup.co.in/contact-us/">
      <span class="quadmenu-item-content">
        <span>                                      <span class="quadmenu-text  hover t_1000">Contact Us</span>
                                      </span>      </span>
    </a>
        </li></ul>    </div>
  </div>
</nav></nav>

											</div>
				</div>
								<div class="mkdf-position-right">
					<div class="mkdf-position-right-inner">
												<div id="custom_html-2" class="widget_text widget widget_custom_html mkdf-header-widget-menu-area"><div class="textwidget custom-html-widget"><a class="phonetop" href="tel:01642240163"><span>Call Us</span>0164-2240163</a></div></div>		
		<a style="margin: 0 20px 0 10px;" class="mkdf-search-opener mkdf-icon-has-hover" href="javascript:void(0)">
            <span class="mkdf-search-opener-wrapper">
                <img class="mkdf-search-image-dark" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/img/search_icon.png " alt="search-image"/>
                <img class="mkdf-search-image-light" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/img/search_icon_light.png " alt="search-image-light"/>
	                        </span>
		</a>
						</div>
				</div>
			</div>
			
			</div>
			
		
	
<div class="mkdf-sticky-header mkdf-menu-position-left">
        <div class="mkdf-sticky-holder">
                    <div class="mkdf-vertical-align-containers">
                <div class="mkdf-position-left">
                    <div class="mkdf-position-left-inner">
                        

<div class="mkdf-logo-wrapper">
    <a itemprop="url" href="https://www.mittalgroup.co.in/" style="height: 47px;">
        <img itemprop="image" class="mkdf-normal-logo" src="https://mittalgroup.co.in/wp-content/uploads/2022/05/logo.png" width="147" height="95"  alt="logo"/>
        <img itemprop="image" class="mkdf-dark-logo" src="https://mittalgroup.co.in/wp-content/uploads/2022/05/logo.png" width="147" height="95"  alt="dark logo"/>        <img itemprop="image" class="mkdf-light-logo" src="https://mittalgroup.co.in/wp-content/uploads/2022/05/logo-light.png" width="147" height="95"  alt="light logo"/>    </a>
</div>

                                                    
<nav class="mkdf-main-menu mkdf-drop-down mkdf-sticky-nav">
    <nav id="quadmenu" class="quadmenu-default_theme quadmenu-v2.3.7 quadmenu-align-right quadmenu-divider-hide quadmenu-carets-show quadmenu-background-color quadmenu-mobile-shadow-show quadmenu-dropdown-shadow-show quadmenu-hover-ripple mega-class quadmenu-is-embed" data-template="embed" data-theme="default_theme" data-unwrap="0" data-breakpoint="768">
  <div class="quadmenu-container">
    <div id="quadmenu_1" class="quadmenu-navbar-collapse collapsed in">
      <ul class="quadmenu-navbar-nav"><li id="menu-item-3389" class="quadmenu-item-3389 quadmenu-item quadmenu-item-object-page quadmenu-item-home quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-0 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">        <a  href="https://www.mittalgroup.co.in/">
      <span class="quadmenu-item-content">
        <span>                                      <span class="quadmenu-text  hover t_1000">Home</span>
                                      </span>      </span>
    </a>
        </li><li id="menu-item-5099" class="quadmenu-item-5099 quadmenu-item quadmenu-item-object-mega quadmenu-item-has-children quadmenu-item-type-mega quadmenu-item-level-0 quadmenu-dropdown quadmenu-has-caret quadmenu-has-title quadmenu-has-link quadmenu-dropdown-right">        <a  title="Properties in Bathinda" href="https://www.mittalgroup.co.in/real-estate-projects/" class="quadmenu-dropdown-toggle hoverintent">
      <span class="quadmenu-item-content">
        <span>                      <span class="quadmenu-caret"></span>
                            <span class="quadmenu-text  hover t_1000">Projects</span>
                                      </span>      </span>
    </a>
            <div id="dropdown-5099" class="quadmenu_btt t_300 quadmenu-dropdown-menu quadmenu-dropdown-stretch-boxed">
            <ul class="quadmenu-row">
        <li id="menu-item-5100" class="quadmenu-item-5100 quadmenu-item quadmenu-item-object-column quadmenu-item-has-children quadmenu-item-type-column col-xs-12 col-sm-4">    <div id="dropdown-5100" class="">
            <ul>
        <li id="menu-item-5103" class="quadmenu-item-5103 quadmenu-item quadmenu-item-object-widget quadmenu-item-type-widget">        <div class="quadmenu-item-widget widget widget_nav_menu">
          <span class="quadmenu-title">RESIDENTIAL</span><div class="menu-residential-container"><ul id="menu-residential-1" class="menu"><li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4877"><a href="https://www.mittalgroup.co.in/ganpati-enclave-bathinda/">Ganpati Enclave</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4878"><a href="https://www.mittalgroup.co.in/sheesh-mahal-bathinda/">Sheesh Mahal</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4879"><a href="https://www.mittalgroup.co.in/sushant-city-1/">Sushant City – 1</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4880"><a href="https://www.mittalgroup.co.in/sushant-city-2/">Sushant City – 2</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4881"><a href="https://www.mittalgroup.co.in/dd-mittal-towers/">DD Mittal Towers</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4882"><a href="https://www.mittalgroup.co.in/sheesh-mahal-heights/">Sheesh Mahal Heights</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-has-children menu-item-4883"><a href="https://www.mittalgroup.co.in/sheesh-mahal-skyline/">Sheesh Mahal Skyline</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5098"><a href="https://www.mittalgroup.co.in/environmental-clearance/">Environmental Clearance</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4884"><a href="https://www.mittalgroup.co.in/sushant-city-2-independent-floors/">Sushant City–2 Independent Floors</a></li>
</ul></div>        </div>
        </li>      </ul>
    </div>
    </li><li id="menu-item-5101" class="quadmenu-item-5101 quadmenu-item quadmenu-item-object-column quadmenu-item-has-children quadmenu-item-type-column col-xs-12 col-sm-4">    <div id="dropdown-5101" class="">
            <ul>
        <li id="menu-item-5104" class="quadmenu-item-5104 quadmenu-item quadmenu-item-object-widget quadmenu-item-type-widget">        <div class="quadmenu-item-widget widget widget_nav_menu">
          <span class="quadmenu-title">COMMERCIAL</span><div class="menu-commercial-container"><ul id="menu-commercial-1" class="menu"><li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4885"><a href="https://www.mittalgroup.co.in/mittal-city-mall/">Mittal City Mall</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4886"><a href="https://www.mittalgroup.co.in/sheesh-mahal-plaza/">Sheesh Mahal Plaza</a></li>
</ul></div>        </div>
        </li>      </ul>
    </div>
    </li><li id="menu-item-5102" class="quadmenu-item-5102 quadmenu-item quadmenu-item-object-column quadmenu-item-has-children quadmenu-item-type-column col-xs-12 col-sm-4">    <div id="dropdown-5102" class="">
            <ul>
        <li id="menu-item-5105" class="quadmenu-item-5105 quadmenu-item quadmenu-item-object-widget quadmenu-item-type-widget">        <div class="quadmenu-item-widget widget widget_nav_menu">
          <span class="quadmenu-title">OUR SPECIFICS</span><div class="menu-our-specifics-container"><ul id="menu-our-specifics-1" class="menu"><li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-5022"><a href="https://www.mittalgroup.co.in/ganpati-temple/">Ganpati Temple</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-5021"><a href="https://www.mittalgroup.co.in/tulips-club-stadium/">Tulips Club &#038; Stadium</a></li>
</ul></div>        </div>
        </li>      </ul>
    </div>
    </li>      </ul>
    </div>
    </li><li id="menu-item-3429" class="quadmenu-item-3429 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-0 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">        <a  href="https://www.mittalgroup.co.in/mittal-group/">
      <span class="quadmenu-item-content">
        <span>                                      <span class="quadmenu-text  hover t_1000">About</span>
                                      </span>      </span>
    </a>
        </li><li id="menu-item-3974" class="quadmenu-item-3974 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-0 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">        <a  href="https://www.mittalgroup.co.in/careers/">
      <span class="quadmenu-item-content">
        <span>                                      <span class="quadmenu-text  hover t_1000">Careers</span>
                                      </span>      </span>
    </a>
        </li><li id="menu-item-3416" class="quadmenu-item-3416 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-0 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">        <a  href="https://www.mittalgroup.co.in/blog/">
      <span class="quadmenu-item-content">
        <span>                                      <span class="quadmenu-text  hover t_1000">Blogs</span>
                                      </span>      </span>
    </a>
        </li><li id="menu-item-3417" class="quadmenu-item-3417 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-0 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">        <a  href="https://www.mittalgroup.co.in/contact-us/">
      <span class="quadmenu-item-content">
        <span>                                      <span class="quadmenu-text  hover t_1000">Contact Us</span>
                                      </span>      </span>
    </a>
        </li></ul>    </div>
  </div>
</nav></nav>

                                            </div>
                </div>
                                <div class="mkdf-position-right">
                    <div class="mkdf-position-right-inner">
                                                                            		
		<a style="margin: 0 10px 4px;" class="mkdf-search-opener mkdf-icon-has-hover" href="javascript:void(0)">
            <span class="mkdf-search-opener-wrapper">
                <img class="mkdf-search-image-dark" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/img/search_icon.png " alt="search-image"/>
                <img class="mkdf-search-image-light" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/img/search_icon_light.png " alt="search-image-light"/>
	                        </span>
		</a>
			
		<a  class="mkdf-property-filter-opener" style="margin: 0 0 0 10px;" href="javascript:void(0)">
            <span class="mkdf-property-filter-opener-wrapper">
                <img class="mkdf-filter-image-dark" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/img/filter_icon.png " alt="filter-image "/>
                <img class="mkdf-filter-image-light" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/img/filter_icon_light.png " alt="filter-image-light "/>
            </span>
		</a>
	                                            </div>
                </div>
            </div>
                </div>
	</div>

	
	</header>


<header class="mkdf-mobile-header">
		
	<div class="mkdf-mobile-header-inner">
		<div class="mkdf-mobile-header-holder">
			<div class="mkdf-grid">
				<div class="mkdf-vertical-align-containers">
					<div class="mkdf-vertical-align-containers">
													<div class="mkdf-mobile-menu-opener">
								<a href="javascript:void(0)">
									<span class="mkdf-mobile-menu-icon">
										<span aria-hidden="true" class="mkdf-icon-font-elegant icon_menu " ></span>									</span>
																	</a>
							</div>
												<div class="mkdf-position-center">
							<div class="mkdf-position-center-inner">
								

<div class="mkdf-mobile-logo-wrapper">
    <a itemprop="url" href="https://www.mittalgroup.co.in/" style="height: 47px">
        <img itemprop="image" src="https://mittalgroup.co.in/wp-content/uploads/2022/05/logo.png" width="147" height="95"  alt="Mobile Logo"/>
    </a>
</div>

							</div>
						</div>
						<div class="mkdf-position-right">
							<div class="mkdf-position-right-inner">
															</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
    <nav class="mkdf-mobile-nav">
        <div class="mkdf-grid">
            <nav id="quadmenu" class="quadmenu-default_theme quadmenu-v2.3.7 quadmenu-align-right quadmenu-divider-hide quadmenu-carets-show quadmenu-background-color quadmenu-mobile-shadow-show quadmenu-dropdown-shadow-show quadmenu-hover-ripple mega-class quadmenu-is-embed" data-template="embed" data-theme="default_theme" data-unwrap="0" data-breakpoint="768">
  <div class="quadmenu-container">
    <div id="quadmenu_2" class="quadmenu-navbar-collapse collapsed in">
      <ul class="quadmenu-navbar-nav"><li id="menu-item-3389" class="quadmenu-item-3389 quadmenu-item quadmenu-item-object-page quadmenu-item-home quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-0 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">        <a  href="https://www.mittalgroup.co.in/">
      <span class="quadmenu-item-content">
        <span>                                      <span class="quadmenu-text  hover t_1000">Home</span>
                                      </span>      </span>
    </a>
        </li><li id="menu-item-5099" class="quadmenu-item-5099 quadmenu-item quadmenu-item-object-mega quadmenu-item-has-children quadmenu-item-type-mega quadmenu-item-level-0 quadmenu-dropdown quadmenu-has-caret quadmenu-has-title quadmenu-has-link quadmenu-dropdown-right">        <a  title="Properties in Bathinda" href="https://www.mittalgroup.co.in/real-estate-projects/" class="quadmenu-dropdown-toggle hoverintent">
      <span class="quadmenu-item-content">
        <span>                      <span class="quadmenu-caret"></span>
                            <span class="quadmenu-text  hover t_1000">Projects</span>
                                      </span>      </span>
    </a>
            <div id="dropdown-5099" class="quadmenu_btt t_300 quadmenu-dropdown-menu quadmenu-dropdown-stretch-boxed">
            <ul class="quadmenu-row">
        <li id="menu-item-5100" class="quadmenu-item-5100 quadmenu-item quadmenu-item-object-column quadmenu-item-has-children quadmenu-item-type-column col-xs-12 col-sm-4">    <div id="dropdown-5100" class="">
            <ul>
        <li id="menu-item-5103" class="quadmenu-item-5103 quadmenu-item quadmenu-item-object-widget quadmenu-item-type-widget">        <div class="quadmenu-item-widget widget widget_nav_menu">
          <span class="quadmenu-title">RESIDENTIAL</span><div class="menu-residential-container"><ul id="menu-residential-2" class="menu"><li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4877"><a href="https://www.mittalgroup.co.in/ganpati-enclave-bathinda/">Ganpati Enclave</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4878"><a href="https://www.mittalgroup.co.in/sheesh-mahal-bathinda/">Sheesh Mahal</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4879"><a href="https://www.mittalgroup.co.in/sushant-city-1/">Sushant City – 1</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4880"><a href="https://www.mittalgroup.co.in/sushant-city-2/">Sushant City – 2</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4881"><a href="https://www.mittalgroup.co.in/dd-mittal-towers/">DD Mittal Towers</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4882"><a href="https://www.mittalgroup.co.in/sheesh-mahal-heights/">Sheesh Mahal Heights</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-has-children menu-item-4883"><a href="https://www.mittalgroup.co.in/sheesh-mahal-skyline/">Sheesh Mahal Skyline</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5098"><a href="https://www.mittalgroup.co.in/environmental-clearance/">Environmental Clearance</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4884"><a href="https://www.mittalgroup.co.in/sushant-city-2-independent-floors/">Sushant City–2 Independent Floors</a></li>
</ul></div>        </div>
        </li>      </ul>
    </div>
    </li><li id="menu-item-5101" class="quadmenu-item-5101 quadmenu-item quadmenu-item-object-column quadmenu-item-has-children quadmenu-item-type-column col-xs-12 col-sm-4">    <div id="dropdown-5101" class="">
            <ul>
        <li id="menu-item-5104" class="quadmenu-item-5104 quadmenu-item quadmenu-item-object-widget quadmenu-item-type-widget">        <div class="quadmenu-item-widget widget widget_nav_menu">
          <span class="quadmenu-title">COMMERCIAL</span><div class="menu-commercial-container"><ul id="menu-commercial-2" class="menu"><li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4885"><a href="https://www.mittalgroup.co.in/mittal-city-mall/">Mittal City Mall</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4886"><a href="https://www.mittalgroup.co.in/sheesh-mahal-plaza/">Sheesh Mahal Plaza</a></li>
</ul></div>        </div>
        </li>      </ul>
    </div>
    </li><li id="menu-item-5102" class="quadmenu-item-5102 quadmenu-item quadmenu-item-object-column quadmenu-item-has-children quadmenu-item-type-column col-xs-12 col-sm-4">    <div id="dropdown-5102" class="">
            <ul>
        <li id="menu-item-5105" class="quadmenu-item-5105 quadmenu-item quadmenu-item-object-widget quadmenu-item-type-widget">        <div class="quadmenu-item-widget widget widget_nav_menu">
          <span class="quadmenu-title">OUR SPECIFICS</span><div class="menu-our-specifics-container"><ul id="menu-our-specifics-2" class="menu"><li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-5022"><a href="https://www.mittalgroup.co.in/ganpati-temple/">Ganpati Temple</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-5021"><a href="https://www.mittalgroup.co.in/tulips-club-stadium/">Tulips Club &#038; Stadium</a></li>
</ul></div>        </div>
        </li>      </ul>
    </div>
    </li>      </ul>
    </div>
    </li><li id="menu-item-3429" class="quadmenu-item-3429 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-0 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">        <a  href="https://www.mittalgroup.co.in/mittal-group/">
      <span class="quadmenu-item-content">
        <span>                                      <span class="quadmenu-text  hover t_1000">About</span>
                                      </span>      </span>
    </a>
        </li><li id="menu-item-3974" class="quadmenu-item-3974 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-0 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">        <a  href="https://www.mittalgroup.co.in/careers/">
      <span class="quadmenu-item-content">
        <span>                                      <span class="quadmenu-text  hover t_1000">Careers</span>
                                      </span>      </span>
    </a>
        </li><li id="menu-item-3416" class="quadmenu-item-3416 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-0 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">        <a  href="https://www.mittalgroup.co.in/blog/">
      <span class="quadmenu-item-content">
        <span>                                      <span class="quadmenu-text  hover t_1000">Blogs</span>
                                      </span>      </span>
    </a>
        </li><li id="menu-item-3417" class="quadmenu-item-3417 quadmenu-item quadmenu-item-object-page quadmenu-item-type-post_type quadmenu-item-type-post_type quadmenu-item-level-0 quadmenu-has-title quadmenu-has-link quadmenu-has-background quadmenu-dropdown-right">        <a  href="https://www.mittalgroup.co.in/contact-us/">
      <span class="quadmenu-item-content">
        <span>                                      <span class="quadmenu-text  hover t_1000">Contact Us</span>
                                      </span>      </span>
    </a>
        </li></ul>    </div>
  </div>
</nav>        </div>
    </nav>

	</div>
	
	</header>

			<a id='mkdf-back-to-top' href='#'>
                <span class="mkdf-icon-stack">
                     <i class="mkdf-icon-linea-icon icon-arrows-up-double-33 "></i>                </span>
			</a>
					
			<div class="mkdf-content" style="height:auto; ">
				<div class="mkdf-content-inner">
					<div class="mkdf-page-not-found">
												
						<h1 class="mkdf-404-title">
							404						</h1>
						
						<h3 class="mkdf-404-subtitle">
							Page not found						</h3>
						
						<p class="mkdf-404-text">
							Oops! The page you are looking for does not exist. It might have been moved or deleted.						</p>
						
						<a itemprop="url" href="https://www.mittalgroup.co.in/" target="_self"  class="mkdf-btn mkdf-btn-large mkdf-btn-solid mkdf-btn-icon"  >
    <span class="mkdf-btn-text">Back to home</span>
    <span aria-hidden="true" class="mkdf-icon-font-elegant arrow_carrot-2right " ></span></a>					</div>
				</div>
			</div>
		</div>
	</div>
    </div> <!-- close div.content_inner -->
	</div> <!-- close div.content -->
					<footer class="mkdf-page-footer">
				<div class="mkdf-footer-top-holder two-colum-footer">
	<div class="mkdf-footer-top-inner mkdf-grid two-colum-grid">
		<div class="mkdf-grid-row mkdf-footer-top-alignment-left">
			<div class="mkdf-column-content mkdf-grid-col-7 foot-left-colum">
				<div class="foot-txt">
						<div class="widget_text widget widget_custom_html"><div class="mkdf-widget-title-holder"><h4 class="mkdf-widget-title">Get In Touch</h4></div><div class="textwidget custom-html-widget"><ul>
<li class="list-phico"><a href="tel:917717303568">+91 771 7303 568</a></li>
<li class="list-mailico"><a href="mailto:noreply@mittalgroup.co.in">noreply@mittalgroup.co.in</a></li>
</ul>
<p class="adrs-txt">Hazi Rattan Link Road , Bathinda-151005 ,Punjab, INDIA</p></div></div>						<!--<h4>Get In Touch</h4>	
						<ul>
							<li class="list-phico"><a href="tel:911642240163">+91 164 2240163</a></li>
							<li class="list-mailico"><a href="mailto:osd@mittalgroup.co.in">osd@mittalgroup.co.in</a></li>
						</ul>
						<p class="adrs-txt">Hazi Rattan Link Road , Bathinda-151005 ,Punjab, INDIA</p>-->
				</div><!--foot-txt-->
			</div><!--col-6-->
			
			<div class="mkdf-column-content mkdf-grid-col-5 foot-right-colum">
				<div class="foot-txt">
					<!--<h4>Subscribe Newsletter</h4>-->	
					      <div class="widget widget_mailpoet_form">
  
      <div class="mkdf-widget-title-holder"><h4 class="mkdf-widget-title">Subscribe Newsletter</h4></div>
  
  <div class="
    mailpoet_form_popup_overlay
      "></div>
  <div
    id="mailpoet_form_1"
    class="
      mailpoet_form
      mailpoet_form_widget
      mailpoet_form_position_
      mailpoet_form_animation_
    "
      >

    <style type="text/css">
     #mailpoet_form_1 .mailpoet_form {  }
#mailpoet_form_1 .mailpoet_column_with_background { padding: 10px; }
#mailpoet_form_1 .mailpoet_form_column:not(:first-child) { margin-left: 20px; }
#mailpoet_form_1 .mailpoet_paragraph { line-height: 20px; margin-bottom: 20px; }
#mailpoet_form_1 .mailpoet_segment_label, #mailpoet_form_1 .mailpoet_text_label, #mailpoet_form_1 .mailpoet_textarea_label, #mailpoet_form_1 .mailpoet_select_label, #mailpoet_form_1 .mailpoet_radio_label, #mailpoet_form_1 .mailpoet_checkbox_label, #mailpoet_form_1 .mailpoet_list_label, #mailpoet_form_1 .mailpoet_date_label { display: block; font-weight: normal; }
#mailpoet_form_1 .mailpoet_text, #mailpoet_form_1 .mailpoet_textarea, #mailpoet_form_1 .mailpoet_select, #mailpoet_form_1 .mailpoet_date_month, #mailpoet_form_1 .mailpoet_date_day, #mailpoet_form_1 .mailpoet_date_year, #mailpoet_form_1 .mailpoet_date { display: block; }
#mailpoet_form_1 .mailpoet_text, #mailpoet_form_1 .mailpoet_textarea { width: 200px; }
#mailpoet_form_1 .mailpoet_checkbox {  }
#mailpoet_form_1 .mailpoet_submit {  }
#mailpoet_form_1 .mailpoet_divider {  }
#mailpoet_form_1 .mailpoet_message {  }
#mailpoet_form_1 .mailpoet_form_loading { width: 30px; text-align: center; line-height: normal; }
#mailpoet_form_1 .mailpoet_form_loading > span { width: 5px; height: 5px; background-color: #5b5b5b; }#mailpoet_form_1{border-radius: 0px;text-align: left;}#mailpoet_form_1 form.mailpoet_form {padding: 20px;}#mailpoet_form_1{width: 100%;}#mailpoet_form_1 .mailpoet_message {margin: 0; padding: 0 20px;}#mailpoet_form_1 .mailpoet_paragraph.last {margin-bottom: 0} @media (max-width: 500px) {#mailpoet_form_1 {background-image: none;}} @media (min-width: 500px) {#mailpoet_form_1 .last .mailpoet_paragraph:last-child {margin-bottom: 0}}  @media (max-width: 500px) {#mailpoet_form_1 .mailpoet_form_column:last-child .mailpoet_paragraph:last-child {margin-bottom: 0}} 
    </style>

    <form
      target="_self"
      method="post"
      action="https://www.mittalgroup.co.in/wp-admin/admin-post.php?action=mailpoet_subscription_form"
      class="mailpoet_form mailpoet_form_form mailpoet_form_widget"
      novalidate
      data-delay=""
      data-exit-intent-enabled=""
      data-font-family=""
      data-cookie-expiration-time=""
    >
      <input type="hidden" name="data[form_id]" value="1" />
      <input type="hidden" name="token" value="f8f31b6e33" />
      <input type="hidden" name="api_version" value="v1" />
      <input type="hidden" name="endpoint" value="subscribers" />
      <input type="hidden" name="mailpoet_method" value="subscribe" />

      <label class="mailpoet_hp_email_label" style="display: none !important;">Please leave this field empty<input type="email" name="data[email]"/></label><div class="mailpoet_paragraph "><label for="form_email_1" class="mailpoet-screen-reader-text" data-automation-id="form_email_label" >Email Address <span class="mailpoet_required">*</span></label><input type="email" autocomplete="email" class="mailpoet_text" id="form_email_1" name="data[form_field_OGMxYThjZDE3NzIxX2VtYWls]" title="Email Address" value="" style="width:100%;box-sizing:border-box;padding:5px;margin: 0 auto 0 0;" data-automation-id="form_email"  placeholder="Email Address *" data-parsley-required="true" data-parsley-minlength="6" data-parsley-maxlength="150" data-parsley-type-message="This value should be a valid email." data-parsley-errors-container=".mailpoet_error_email_" data-parsley-required-message="This field is required."/></div>
<div class="mailpoet_paragraph "><input type="submit" class="mailpoet_submit" value="Subscribe!" data-automation-id="subscribe-submit-button" style="width:100%;box-sizing:border-box;padding:5px;margin: 0 auto 0 0;border-color:transparent;" /><span class="mailpoet_form_loading"><span class="mailpoet_bounce1"></span><span class="mailpoet_bounce2"></span><span class="mailpoet_bounce3"></span></span></div>

      <div class="mailpoet_message">
        <p class="mailpoet_validate_success"
                style="display:none;"
                >Check your inbox or spam folder to confirm your subscription.
        </p>
        <p class="mailpoet_validate_error"
                style="display:none;"
                >        </p>
      </div>
    </form>

      </div>

      </div>
  				</div>
			</div><!--col-6-->		
			
		</div><!--mkdf-grid-row-->	
	</div><!--mkdf-footer-top-inner-->	
</div>

<div class="mkdf-middle-footer mkdf-footer-top-holder  ">
	<div class="mkdf-footer-top-inner mkdf-grid">
		<div class="mkdf-grid-row mkdf-footer-top-alignment-left">
							<div class="mkdf-column-content middle-footer-colum middle-footer-item-1  mkdf-grid-col-3">
					<div id="text-2" class="widget mkdf-footer-column-1 widget_text">			<div class="textwidget"><p><img loading="lazy" decoding="async" class="alignnone size-full wp-image-3434" src="https://mittalgroup.co.in/wp-content/uploads/2022/05/logo-footer.png" alt="" width="128" height="131" /></p>
</div>
		</div>		
		<a class="mkdf-social-icon-widget-holder mkdf-icon-has-hover" data-hover-color="#bf9410" style="color: #FFFFFF;;font-size: 16px;margin: 8px 10px 0 0;" href="https://www.facebook.com/mittalgroupindia" target="_blank">
			<span class="mkdf-social-icon-widget fa fa-facebook     "></span>		</a>
				
		<a class="mkdf-social-icon-widget-holder mkdf-icon-has-hover" data-hover-color="#bf9410" style="color: #ffffff;;font-size: 16px;margin: 8px 10px 0 0;" href="https://www.instagram.com/mittalgroupindia" target="_blank">
			<span class="mkdf-social-icon-widget fa fa-instagram     "></span>		</a>
				
		<a class="mkdf-social-icon-widget-holder mkdf-icon-has-hover" data-hover-color="#bf9410" style="color: #FFFFFF;;font-size: 16px;margin: 9px 10px 0 0;" href="https://twitter.com/mittalgroupind" target="_blank">
			<span class="mkdf-social-icon-widget fa fa-twitter     "></span>		</a>
				
		<a class="mkdf-social-icon-widget-holder mkdf-icon-has-hover" data-hover-color="#bf9410" style="color: #FFFFFF;;font-size: 16px;margin: 9px 10px 0 0;" href="https://www.youtube.com/c/MittalGroupIndia" target="_blank">
			<span class="mkdf-social-icon-widget fa fa-youtube     "></span>		</a>
				
		<a class="mkdf-social-icon-widget-holder mkdf-icon-has-hover" data-hover-color="#bf9410" style="color: #FFFFFF;;font-size: 16px;margin: 9px 10px 0 0;" href="https://in.pinterest.com/mittalgroupindia" target="_blank">
			<span class="mkdf-social-icon-widget fa fa-pinterest     "></span>		</a>
				
		<a class="mkdf-social-icon-widget-holder mkdf-icon-has-hover" data-hover-color="#bf9410" style="color: #FFFFFF;;font-size: 16px;margin: 8px 0 0 0;" href="https://www.linkedin.com/company/mittalgroupindia" target="_blank">
			<span class="mkdf-social-icon-widget fa fa-linkedin     "></span>		</a>
						</div>
							<div class="mkdf-column-content middle-footer-colum middle-footer-item-2  mkdf-grid-col-3">
					<div id="nav_menu-3" class="widget mkdf-footer-column-2 widget_nav_menu"><div class="mkdf-widget-title-holder"><h4 class="mkdf-widget-title">Key Business</h4></div><div class="menu-key-business-container"><ul id="menu-key-business" class="menu"><li id="menu-item-4098" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4098"><a href="https://www.mittalgroup.co.in/real-estate/">Real Estate</a></li>
<li id="menu-item-4038" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4038"><a href="https://www.mittalgroup.co.in/edible-oil/">Edible Oil</a></li>
<li id="menu-item-4174" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4174"><a href="https://www.mittalgroup.co.in/distillery-ethanol-industry/">Distillery Plant Bathinda</a></li>
</ul></div></div>				</div>
							<div class="mkdf-column-content middle-footer-colum middle-footer-item-3  mkdf-grid-col-3">
					<div id="nav_menu-5" class="widget mkdf-footer-column-3 widget_nav_menu"><div class="mkdf-widget-title-holder"><h4 class="mkdf-widget-title">Information</h4></div><div class="menu-information-container"><ul id="menu-information" class="menu"><li id="menu-item-4771" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-4771"><a href="https://www.mittalgroup.co.in/">Home</a></li>
<li id="menu-item-4186" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4186"><a href="https://www.mittalgroup.co.in/mittal-group/">About Us</a></li>
<li id="menu-item-4188" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4188"><a href="https://www.mittalgroup.co.in/careers/">Careers</a></li>
<li id="menu-item-4520" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4520"><a href="https://www.mittalgroup.co.in/news-media/">News &#038; Media</a></li>
<li id="menu-item-4565" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4565"><a href="https://www.mittalgroup.co.in/award-recognition/">Award &#038; Recognition</a></li>
<li id="menu-item-4187" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4187"><a href="https://www.mittalgroup.co.in/contact-us/">Contact Us</a></li>
</ul></div></div>				</div>
							<div class="mkdf-column-content middle-footer-colum middle-footer-item-4  mkdf-grid-col-3">
					<div id="nav_menu-7" class="widget mkdf-footer-column-4 widget_nav_menu"><div class="mkdf-widget-title-holder"><h4 class="mkdf-widget-title">Real Estate Projects</h4></div><div class="menu-projects-container"><ul id="menu-projects" class="menu"><li id="menu-item-4193" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4193"><a href="https://www.mittalgroup.co.in/ganpati-enclave-bathinda/">Ganpati Enclave</a></li>
<li id="menu-item-4189" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4189"><a href="https://www.mittalgroup.co.in/sheesh-mahal-bathinda/">Sheesh Mahal</a></li>
<li id="menu-item-4191" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4191"><a href="https://www.mittalgroup.co.in/sushant-city-1/">Sushant City – 1</a></li>
<li id="menu-item-4192" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4192"><a href="https://www.mittalgroup.co.in/sushant-city-2/">Sushant City – 2</a></li>
<li id="menu-item-4190" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4190"><a href="https://www.mittalgroup.co.in/dd-mittal-towers/">DD Mittal Towers</a></li>
<li id="menu-item-4194" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4194"><a href="https://www.mittalgroup.co.in/sheesh-mahal-heights/">Sheesh Mahal Heights</a></li>
<li id="menu-item-4732" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4732"><a href="https://www.mittalgroup.co.in/mittal-city-mall/">Mittal City Mall</a></li>
<li id="menu-item-4733" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4733"><a href="https://www.mittalgroup.co.in/sheesh-mahal-plaza/">Sheesh Mahal Plaza</a></li>
<li id="menu-item-4770" class="menu-item menu-item-type-post_type menu-item-object-property-item menu-item-4770"><a href="https://www.mittalgroup.co.in/sheesh-mahal-skyline/">Sheesh Mahal Skyline</a></li>
</ul></div></div>				</div>
					</div>
	</div>
</div><div class="mkdf-footer-bottom-holder  light-skin">
	<div class="mkdf-footer-bottom-inner mkdf-grid">
		<div class="mkdf-grid-row ">
							<div class="mkdf-grid-col-6">
					<div id="text-6" class="widget mkdf-footer-bottom-column-1 widget_text">			<div class="textwidget"><p style="color: #555555;">Copyright © 2022 Mittal Group. All rights reserved.</p>
</div>
		</div>				</div>
							<div class="mkdf-grid-col-6">
					<div id="nav_menu-4" class="widget mkdf-footer-bottom-column-2 widget_nav_menu"><div class="menu-privacy-container"><ul id="menu-privacy" class="menu"><li id="menu-item-4203" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4203"><a href="https://www.mittalgroup.co.in/disclaimer/">Disclaimer</a></li>
<li id="menu-item-4204" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4204"><a href="https://www.mittalgroup.co.in/privacy-policy/">Privacy Policy</a></li>
<li id="menu-item-4202" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4202"><a href="https://www.mittalgroup.co.in/terms-and-conditions/">Terms and Conditions</a></li>
</ul></div></div>				</div>
					</div>
	</div>
</div>			</footer>
			</div> <!-- close div.mkdf-wrapper-inner  -->
</div> <!-- close div.mkdf-wrapper -->
	
	
	<section class="sticky-footer">
		<div class="footer-nav">
			<a href="tel:917717303568"> <i class="fa fa-phone" aria-hidden="true"></i> Call Us</a>
			<a href="https://api.whatsapp.com/send?phone=917717303568"> <i class="fa fa-whatsapp" aria-hidden="true"></i> Whats App</a>
			<a target="_blank" href="https://goo.gl/maps/x7BNSq8F8uhzuLGK6"> <i class="fa fa-map-marker" aria-hidden="true"></i> Locate Us</a>
		</div>
	</section>
	
	
<script>

    /*--Paralax Menu on Single Property-----*/
    
    jQuery('document').ready(function(){
        jQuery('#property-menu-paralax ul li a').click(function(){
            var datahref = jQuery(this).attr('datavalue');
            jQuery('html, body').animate({ scrollTop: jQuery(datahref).offset().top }, 'slow');      
        })
        
    /*--Fixed Paralax Menu on Scroll-----*/    
        var shrinkHeader = 670;
    	jQuery(window).scroll(function() {
    		var scroll = getCurrentScroll();
    		  if ( scroll >= shrinkHeader ) {
    			   jQuery('.paralax-section').addClass('fixed-paralax');
    			}
    			else {
    				jQuery('.paralax-section').removeClass('fixed-paralax');
    			}
    	  });
	  
    	function getCurrentScroll() {
    		return window.pageYOffset || document.documentElement.scrollTop;
        }
        
        /*------List View More Less--------*/

             
            jQuery('.lessmore ul').each(function(){
              var LiN = jQuery(this).find('li').length;
              
              if( LiN > 3){    
                jQuery('li', this).eq(2).nextAll().hide().addClass('toggleable');
                jQuery(this).append('<p class="more">More...</p>');    
              }
              
            });
            
           jQuery('.lessmore ul').on('click','.more', function(){
              if( jQuery(this).hasClass('less') ){    
                jQuery(this).text('More...').removeClass('less');    
              }else{
                jQuery(this).text('Less...').addClass('less'); 
              }
              jQuery(this).siblings('li.toggleable').slideToggle();
                
            });
         /*------Gallery View More Less--------*/  
         
        jQuery('.lessmore-gallery .mkdf-ig-grid').each(function(){
          var LiN = jQuery(this).find('.mkdf-ig-image').length;
          if( LiN > 2){    
            jQuery('.mkdf-ig-image', this).eq(1).nextAll().hide().addClass('toggleable');
            jQuery(this).append('<div class="viewmore hover-button">More</div>');    
          }
        });
        
        jQuery('.lessmore-gallery .mkdf-ig-grid').on('click','.viewmore', function(){
              if( jQuery(this).hasClass('less') ){    
                jQuery(this).text('More').removeClass('less');    
              }else{
                jQuery(this).text('Less').addClass('less'); 
              }
              jQuery(this).siblings('.mkdf-ig-image.toggleable').slideToggle();
                
        });
        
        
        /*------Table View More Less--------*/  
         
         jQuery('table.lessmore-table tbody').each(function(){
              var LiN = jQuery(this).find('tr').length;
              
              if( LiN > 3){    
                jQuery('tr', this).eq(2).nextAll().hide().addClass('toggleable');
                jQuery(this).append('<p class="more">More...</p>');    
              }
              
            });
            
           jQuery('table.lessmore-table').on('click','.more', function(){
              if( jQuery(this).hasClass('less') ){    
                jQuery(this).text('More...').removeClass('less');    
              }else{
                jQuery(this).text('Less...').addClass('less'); 
              }
              jQuery(this).siblings('tr.toggleable').slideToggle();
                
        });
        
    /*-------More Less text Toggle--------*/    
     jQuery('.text-more-box').on('click','.viewmore', function(){    
        jQuery('.toggle-box').slideToggle('slow'); 
     });   
        
    })
</script>





<link rel='stylesheet' id='mailpoet_public-css' href='https://www.mittalgroup.co.in/wp-content/plugins/mailpoet/assets/dist/css/mailpoet-public.9cd759ea.css?ver=6.7.1' type='text/css' media='all' />
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.7.6" id="swv-js"></script>
<script type="text/javascript" id="contact-form-7-js-extra">
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/www.mittalgroup.co.in\/wp-json\/","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.7.6" id="contact-form-7-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3" id="jquery-ui-core-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-includes/js/jquery/ui/tabs.min.js?ver=1.13.3" id="jquery-ui-tabs-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-includes/js/jquery/ui/accordion.min.js?ver=1.13.3" id="jquery-ui-accordion-js"></script>
<script type="text/javascript" id="mediaelement-core-js-before">
/* <![CDATA[ */
var mejsL10n = {"language":"en","strings":{"mejs.download-file":"Download File","mejs.install-flash":"You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\/\/get.adobe.com\/flashplayer\/","mejs.fullscreen":"Fullscreen","mejs.play":"Play","mejs.pause":"Pause","mejs.time-slider":"Time Slider","mejs.time-help-text":"Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.","mejs.live-broadcast":"Live Broadcast","mejs.volume-help-text":"Use Up\/Down Arrow keys to increase or decrease volume.","mejs.unmute":"Unmute","mejs.mute":"Mute","mejs.volume-slider":"Volume Slider","mejs.video-player":"Video Player","mejs.audio-player":"Audio Player","mejs.captions-subtitles":"Captions\/Subtitles","mejs.captions-chapters":"Chapters","mejs.none":"None","mejs.afrikaans":"Afrikaans","mejs.albanian":"Albanian","mejs.arabic":"Arabic","mejs.belarusian":"Belarusian","mejs.bulgarian":"Bulgarian","mejs.catalan":"Catalan","mejs.chinese":"Chinese","mejs.chinese-simplified":"Chinese (Simplified)","mejs.chinese-traditional":"Chinese (Traditional)","mejs.croatian":"Croatian","mejs.czech":"Czech","mejs.danish":"Danish","mejs.dutch":"Dutch","mejs.english":"English","mejs.estonian":"Estonian","mejs.filipino":"Filipino","mejs.finnish":"Finnish","mejs.french":"French","mejs.galician":"Galician","mejs.german":"German","mejs.greek":"Greek","mejs.haitian-creole":"Haitian Creole","mejs.hebrew":"Hebrew","mejs.hindi":"Hindi","mejs.hungarian":"Hungarian","mejs.icelandic":"Icelandic","mejs.indonesian":"Indonesian","mejs.irish":"Irish","mejs.italian":"Italian","mejs.japanese":"Japanese","mejs.korean":"Korean","mejs.latvian":"Latvian","mejs.lithuanian":"Lithuanian","mejs.macedonian":"Macedonian","mejs.malay":"Malay","mejs.maltese":"Maltese","mejs.norwegian":"Norwegian","mejs.persian":"Persian","mejs.polish":"Polish","mejs.portuguese":"Portuguese","mejs.romanian":"Romanian","mejs.russian":"Russian","mejs.serbian":"Serbian","mejs.slovak":"Slovak","mejs.slovenian":"Slovenian","mejs.spanish":"Spanish","mejs.swahili":"Swahili","mejs.swedish":"Swedish","mejs.tagalog":"Tagalog","mejs.thai":"Thai","mejs.turkish":"Turkish","mejs.ukrainian":"Ukrainian","mejs.vietnamese":"Vietnamese","mejs.welsh":"Welsh","mejs.yiddish":"Yiddish"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=4.2.17" id="mediaelement-core-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-includes/js/mediaelement/mediaelement-migrate.min.js?ver=6.7.1" id="mediaelement-migrate-js"></script>
<script type="text/javascript" id="mediaelement-js-extra">
/* <![CDATA[ */
var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/","classPrefix":"mejs-","stretching":"responsive","audioShortcodeLibrary":"mediaelement","videoShortcodeLibrary":"mediaelement"};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=6.7.1" id="wp-mediaelement-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/js/modules/plugins/jquery.appear.js?ver=6.7.1" id="appear-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/js/modules/plugins/modernizr.min.js?ver=6.7.1" id="modernizr-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-includes/js/hoverIntent.min.js?ver=1.10.2" id="hoverIntent-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/js/modules/plugins/jquery.plugin.js?ver=6.7.1" id="jquery-plugin-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/js/modules/plugins/owl.carousel.min.js?ver=6.7.1" id="owl-carousel-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/js/modules/plugins/jquery.waypoints.min.js?ver=6.7.1" id="waypoints-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/js/modules/plugins/Chart.min.js?ver=6.7.1" id="chart-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/js/modules/plugins/fluidvids.min.js?ver=6.7.1" id="fluidvids-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/plugins/js_composer/assets/lib/prettyphoto/js/jquery.prettyPhoto.min.js?ver=6.11.0" id="prettyphoto-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/js/modules/plugins/perfect-scrollbar.jquery.min.js?ver=6.7.1" id="perfect-scrollbar-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/js/modules/plugins/ScrollToPlugin.min.js?ver=6.7.1" id="scroll-to-plugin-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/js/modules/plugins/parallax.min.js?ver=6.7.1" id="parallax-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/js/modules/plugins/jquery.waitforimages.js?ver=6.7.1" id="waitforimages-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/js/modules/plugins/jquery.easing.1.3.js?ver=6.7.1" id="jquery-easing-1.3-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/plugins/js_composer/assets/lib/bower/isotope/dist/isotope.pkgd.min.js?ver=6.11.0" id="isotope-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/js/modules/plugins/packery-mode.pkgd.min.js?ver=6.7.1" id="packery-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/js/modules/plugins/slick.min.js?ver=6.7.1" id="slick-slider-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/plugins/mkdf-core/shortcodes/countdown/assets/js/plugins/jquery.countdown.min.js?ver=6.7.1" id="countdown-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/plugins/mkdf-core/shortcodes/counter/assets/js/plugins/counter.js?ver=6.7.1" id="counter-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/plugins/mkdf-core/shortcodes/counter/assets/js/plugins/absoluteCounter.min.js?ver=6.7.1" id="absoluteCounter-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/plugins/mkdf-core/shortcodes/custom-font/assets/js/plugins/typed.js?ver=6.7.1" id="typed-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/plugins/mkdf-core/shortcodes/full-screen-sections/assets/js/plugins/jquery.fullPage.min.js?ver=6.7.1" id="fullPage-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/plugins/mkdf-core/shortcodes/pie-chart/assets/js/plugins/easypiechart.js?ver=6.7.1" id="easypiechart-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/plugins/mkdf-core/post-types/property/shortcodes/interactive-property-list/assets/js/plugins/TweenMax.min.js?ver=6.7.1" id="tweenMax-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/js/modules/plugins/TweenLite.min.js?ver=6.7.1" id="tween-lite-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/js/modules/plugins/smoothPageScroll.js?ver=6.7.1" id="smooth-page-scroll-js"></script>
<script type="text/javascript" id="kastell-mkdf-modules-js-extra">
/* <![CDATA[ */
var mkdfGlobalVars = {"vars":{"mkdfAddForAdminBar":0,"mkdfElementAppearAmount":-100,"mkdfAjaxUrl":"https:\/\/www.mittalgroup.co.in\/wp-admin\/admin-ajax.php","mkdfStickyHeaderHeight":70,"mkdfStickyHeaderTransparencyHeight":70,"mkdfTopBarHeight":0,"mkdfLogoAreaHeight":0,"mkdfMenuAreaHeight":120,"mkdfMobileHeaderHeight":100}};
var mkdfPerPageVars = {"vars":{"mkdfStickyScrollAmount":0,"mkdfHeaderTransparencyHeight":0,"mkdfHeaderVerticalWidth":0}};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/themes/kastell/assets/js/modules.min.js?ver=6.7.1" id="kastell-mkdf-modules-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/plugins/quadmenu/assets/frontend/pscrollbar/perfect-scrollbar.jquery.min.js?ver=2.3.7" id="pscrollbar-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/plugins/quadmenu/assets/frontend/owlcarousel/owl.carousel.min.js?ver=2.3.7" id="owlcarousel-js"></script>
<script type="text/javascript" id="quadmenu-js-extra">
/* <![CDATA[ */
var quadmenu = {"ajaxurl":"https:\/\/www.mittalgroup.co.in\/wp-admin\/admin-ajax.php","gutter":"30"};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/plugins/quadmenu/assets/frontend/js/quadmenu.min.js?ver=2.3.7" id="quadmenu-js"></script>
<script type="text/javascript" src="https://www.google.com/recaptcha/api.js?render=6LeQehcmAAAAADXNn8xL5EWOCfhC8RJb_iEm3LMi&amp;ver=3.0" id="google-recaptcha-js"></script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0" id="wp-polyfill-js"></script>
<script type="text/javascript" id="wpcf7-recaptcha-js-extra">
/* <![CDATA[ */
var wpcf7_recaptcha = {"sitekey":"6LeQehcmAAAAADXNn8xL5EWOCfhC8RJb_iEm3LMi","actions":{"homepage":"homepage","contactform":"contactform"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/plugins/contact-form-7/modules/recaptcha/index.js?ver=5.7.6" id="wpcf7-recaptcha-js"></script>
<script type="text/javascript" id="mailpoet_public-js-extra">
/* <![CDATA[ */
var MailPoetForm = {"ajax_url":"https:\/\/www.mittalgroup.co.in\/wp-admin\/admin-ajax.php","is_rtl":""};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/plugins/mailpoet/assets/dist/js/public.js?ver=4.16.0" id="mailpoet_public-js"></script>
<script type="text/javascript" id="mailpoet_public-js-after">
/* <![CDATA[ */
function initMailpoetTranslation() {
  if (typeof MailPoet !== 'undefined') {
    MailPoet.I18n.add('ajaxFailedErrorMessage', 'An error has happened while performing a request, please try again later.')
  } else {
    setTimeout(initMailpoetTranslation, 250);
  }
}
setTimeout(initMailpoetTranslation, 250);
/* ]]> */
</script>
<script type="text/javascript" src="https://www.mittalgroup.co.in/wp-content/plugins/mkdf-core/shortcodes/image-map-gallery/assets/exclude_js/image-map-gallery.js?ver=6.7.1" id="mkdf-core-imp-script-js"></script>
</body>
</html>
</body>
</html>